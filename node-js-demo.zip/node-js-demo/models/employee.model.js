const mongoose = require('mongoose');
const schema = mongoose.Schema;

let employeeSchema = new schema({
    firstName : {type: String},
    lastName : {type: String}
},
{
    collection: 'employees' },
{
    versionKey: false
});


// Export the model
module.exports = mongoose.model('employee', employeeSchema);