const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const auditRoute = require('./routes/route');
const config = require('config');
const fs = require('fs');

const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

// Set up mongoose connection

const mongoUrl = 'mongodb://localhost:27017/?readPreference=primary&appname=MongoDB%20Compass%20Community&ssl=false'

//const connectionOptions = {
//  server: {
//    ssl: false,
//    sslValidate: false,
////    sslCA: ca,
////    useUnifiedTopology: true,
////    useNewUrlParser: true
//  }
//}

//mongoose.connect(mongoUrl,connectionOptions);
mongoose.connect(mongoUrl);
mongoose.Promise = global.Promise;
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));

console.log('Mongo Database online');
app.use('/', auditRoute);

const HOST = '0.0.0.0';
const PORT = 8083;

const server = app.listen(PORT, HOST);
console.log(`Running on http://${HOST}:${PORT}`);

// The signals we want to handle
// NOTE: although it is tempting, the SIGKILL signal (9) cannot be intercepted and handled
var signals = {
  'SIGHUP': 1,
  'SIGINT': 2,
  'SIGTERM': 15
};

// Create a listener for each of the signals that we want to handle
Object.keys(signals).forEach((signal) => {
  process.on(signal, () => {

  console.log(`Process received a ${signal} signal`);
    shutdown(signal, signals[signal]);
  });
});

// Do any necessary shutdown logic for our application here
const shutdown = (signal, value) => {
  mongoose.connection.close();
   console.log("Shutdown!");
  server.close(() => {
    console.log(`Server stopped by ${signal} with value ${value}`);
    process.exit(0);
  });
};
