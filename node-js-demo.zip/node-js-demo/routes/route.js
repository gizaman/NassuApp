// Initialize express router
let router = require('express').Router();

var cors = require('cors');
router.use(cors());

var employeeController = require('../controllers/employee.controller');

router.route('/v1/employees').post(employeeController.persistEmployee);

module.exports = router;