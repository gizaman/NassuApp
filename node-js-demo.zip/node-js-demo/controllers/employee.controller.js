const employeeModel = require('../models/employee.model');

//const Logger = require('../services/logger_service')
//const logger = new Logger('employeeController')

exports.persistEmployee = async function (req, res) {

    let employee = new employeeModel(
        {
            firstName: req.body.firstName,
            lastName: req.body.lastName
        }
    );
    var result = await employee.save(function (err, obj) {
        if (err) {
            console.log(err);
            res.status(500).send(err);
        }
        else if(!obj) throw new Error("no object found")
        else {
            res.status(201).send(obj);
        }
    });
};


